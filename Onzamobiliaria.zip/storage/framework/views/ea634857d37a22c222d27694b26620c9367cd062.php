<?php $__env->startSection('title', 'mobiliria'); ?>

<?php $__env->startSection('content_header'); ?>
<section class="content-header">
    <h1>
        Mobiliaria
        <small>Editar</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="/home"><i class="fa fa-dashboard"></i> Inicio</a></li>
        <li><a href="/admin/mobiliaria"><i class="fa fa-dashboard"></i> Mobiliaria</a></li>
        <li class="active">Editar</li>
    </ol>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="row">
        <div class="box">
            <div class="box-header with-border">
                <h3 class="box-title">Editar Mobiliaria</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
                <?php echo e(Form::open(['route' => ['mobiliaria.update', $real_state->id], 'method' => 'PUT', 'files' => true])); ?>

                <div class="container">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Descripción</label>
                                <input type="text" name="description" value="<?php echo e($real_state->description); ?>" class="form-control">
                                <input type="hidden" name="status" value="<?php echo e($real_state->status); ?>">
                                <?php if($errors): ?>
                                <span class="text-danger"> <?php echo e($errors->first('description')); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <button class="btn btn-primary">Guardar</button>
                            </div>
                        </div>
                    </div>
                </div>
                <?php echo e(Form::close()); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Onzamobiliaria\resources\views/mobiliaria/edit.blade.php ENDPATH**/ ?>